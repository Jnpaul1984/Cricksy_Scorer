from __future__ import annotations
from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import Literal

from services.dls_service import resource_remaining, calc_target

router = APIRouter(prefix="/dls", tags=["dls"])

class ResourceIn(BaseModel):
    format_overs: Literal[20, 50]
    balls_left: int = Field(ge=0)
    wickets_lost: int = Field(ge=0, le=9)

class ResourceOut(BaseModel):
    resource: float

@router.post("/resources", response_model=ResourceOut)
def post_resources(body: ResourceIn) -> ResourceOut:
    r = resource_remaining(body.format_overs, balls_left=body.balls_left, wickets_lost=body.wickets_lost)
    return ResourceOut(resource=r)

class TargetIn(BaseModel):
    format_overs: Literal[20, 50]
    team1_score: int = Field(ge=0)
    team1_resources: float = Field(ge=0, le=100)
    team2_balls_left: int = Field(ge=0)
    team2_wickets_lost: int = Field(ge=0, le=9)
    G50: int = 245

class TargetOut(BaseModel):
    target: int
    team2_resources: float

@router.post("/calc_target", response_model=TargetOut)
def post_calc_target(body: TargetIn) -> TargetOut:
    r2 = resource_remaining(body.format_overs, balls_left=body.team2_balls_left, wickets_lost=body.team2_wickets_lost)
    tgt = calc_target(body.team1_score, body.team1_resources, r2, body.G50)
    return TargetOut(target=tgt, team2_resources=r2)
